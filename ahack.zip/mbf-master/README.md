# Multi Brute Force

REZKI ANJING

## Installation
```
pkg install python2
pip2 install requests bs4
```

## Run script
```
cd mbf
python2 run.py
```
